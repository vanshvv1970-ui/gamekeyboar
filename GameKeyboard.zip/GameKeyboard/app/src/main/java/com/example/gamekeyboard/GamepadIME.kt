package com.example.gamekeyboard

import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager

class GamepadIME : InputMethodService() {

    private var gamepadMode = true

    override fun onCreateInputView(): View =
        GamepadView(
            this,
            onKey = { code, down -> sendKey(code, down) },
            onSwitchKeyboard = {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            },
            onToggleMode = { gamepadMode = !gamepadMode; gamepadMode }
        )

    override fun onEvaluateFullscreenMode() = false

    private fun sendKey(code: Int, down: Boolean) {
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        val mapped = if (gamepadMode) code else KeyMap.toKeyboard(code)
        val source = if (gamepadMode) InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_KEYBOARD
                     else InputDevice.SOURCE_KEYBOARD
        val ev = KeyEvent(
            now, now,
            if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP,
            mapped, 0, 0, KeyCharacterMapDevice, 0,
            KeyEvent.FLAG_SOFT_KEYBOARD or KeyEvent.FLAG_KEEP_TOUCH_MODE, source
        )
        ic.sendKeyEvent(ev)
    }

    private companion object { const val KeyCharacterMapDevice = -1 }
}

/** Edit this table to change what keyboard mode sends. */
object KeyMap {
    fun toKeyboard(code: Int): Int = when (code) {
        KeyEvent.KEYCODE_BUTTON_A -> KeyEvent.KEYCODE_Z
        KeyEvent.KEYCODE_BUTTON_B -> KeyEvent.KEYCODE_X
        KeyEvent.KEYCODE_BUTTON_X -> KeyEvent.KEYCODE_A
        KeyEvent.KEYCODE_BUTTON_Y -> KeyEvent.KEYCODE_S
        KeyEvent.KEYCODE_BUTTON_L1 -> KeyEvent.KEYCODE_Q
        KeyEvent.KEYCODE_BUTTON_R1 -> KeyEvent.KEYCODE_W
        KeyEvent.KEYCODE_BUTTON_START -> KeyEvent.KEYCODE_ENTER
        KeyEvent.KEYCODE_BUTTON_SELECT -> KeyEvent.KEYCODE_SPACE
        else -> code // D-pad stays as arrow keys
    }
}
