package com.example.gamekeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.TypedValue
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

class GamepadView(
    context: Context,
    private val onKey: (Int, Boolean) -> Unit,
    private val onSwitchKeyboard: () -> Unit,
    private val onToggleMode: () -> Boolean
) : View(context) {

    private class Btn(val label: String, val code: Int, val fx: Float, val fy: Float, val scale: Float = 1f)

    private companion object {
        const val ACTION_MODE = -1
        const val ACTION_SWITCH = -2
    }

    private val buttons = listOf(
        Btn("▲", KeyEvent.KEYCODE_DPAD_UP, 0.17f, 0.30f),
        Btn("▼", KeyEvent.KEYCODE_DPAD_DOWN, 0.17f, 0.82f),
        Btn("◀", KeyEvent.KEYCODE_DPAD_LEFT, 0.07f, 0.56f),
        Btn("▶", KeyEvent.KEYCODE_DPAD_RIGHT, 0.27f, 0.56f),
        Btn("Y", KeyEvent.KEYCODE_BUTTON_Y, 0.83f, 0.30f),
        Btn("A", KeyEvent.KEYCODE_BUTTON_A, 0.83f, 0.82f),
        Btn("X", KeyEvent.KEYCODE_BUTTON_X, 0.73f, 0.56f),
        Btn("B", KeyEvent.KEYCODE_BUTTON_B, 0.93f, 0.56f),
        Btn("L1", KeyEvent.KEYCODE_BUTTON_L1, 0.08f, 0.07f, 0.7f),
        Btn("R1", KeyEvent.KEYCODE_BUTTON_R1, 0.92f, 0.07f, 0.7f),
        Btn("SEL", KeyEvent.KEYCODE_BUTTON_SELECT, 0.42f, 0.82f, 0.7f),
        Btn("START", KeyEvent.KEYCODE_BUTTON_START, 0.58f, 0.82f, 0.7f),
        Btn("GP", ACTION_MODE, 0.42f, 0.30f, 0.6f),
        Btn("⌨", ACTION_SWITCH, 0.58f, 0.30f, 0.6f)
    )

    private val pressed = HashMap<Int, Int>() // pointerId -> button index
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private var modeLabel = "GP"

    override fun onMeasure(w: Int, h: Int) {
        val height = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, 230f, resources.displayMetrics).toInt()
        setMeasuredDimension(MeasureSpec.getSize(w), height)
    }

    private fun radius(b: Btn) = min(width, height) * 0.13f * b.scale

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.argb(235, 20, 20, 24))
        buttons.forEachIndexed { i, b ->
            val on = pressed.containsValue(i)
            fill.color = if (on) Color.rgb(90, 170, 255) else Color.rgb(60, 62, 72)
            val cx = b.fx * width; val cy = b.fy * height; val r = radius(b)
            c.drawCircle(cx, cy, r, fill)
            text.textSize = r * 0.8f
            val label = if (b.code == ACTION_MODE) modeLabel else b.label
            c.drawText(label, cx, cy + text.textSize / 3f, text)
        }
    }

    private fun hit(x: Float, y: Float): Int {
        var best = -1; var bestD = Float.MAX_VALUE
        buttons.forEachIndexed { i, b ->
            val d = hypot(x - b.fx * width, y - b.fy * height)
            if (d <= radius(b) * 1.25f && d < bestD) { best = i; bestD = d }
        }
        return best
    }

    private fun press(pid: Int, idx: Int) {
        val b = buttons[idx]
        when (b.code) {
            ACTION_MODE -> { modeLabel = if (onToggleMode()) "GP" else "KB" }
            ACTION_SWITCH -> onSwitchKeyboard()
            else -> { onKey(b.code, true); pressed[pid] = idx; buzz() }
        }
        if (b.code < 0) pressed[pid] = idx
    }

    private fun release(pid: Int) {
        val idx = pressed.remove(pid) ?: return
        val code = buttons[idx].code
        if (code >= 0) onKey(code, false)
    }

    private fun buzz() {
        val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(12, 80))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val idx = hit(e.getX(i), e.getY(i))
                if (idx >= 0) press(e.getPointerId(i), idx)
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) {
                val pid = e.getPointerId(i)
                val idx = hit(e.getX(i), e.getY(i))
                val cur = pressed[pid]
                if (cur != idx && (cur == null || buttons[cur].code >= 0)) {
                    release(pid)
                    if (idx >= 0 && buttons[idx].code >= 0) press(pid, idx)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> release(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> pressed.keys.toList().forEach { release(it) }
        }
        invalidate()
        return true
    }
}
