# Game Keyboard (non-root)
Open this folder in Android Studio (Koala or newer), let it sync, then Run on your phone
(or Build > Build APK). Android Studio generates the Gradle wrapper jar for you.
Then: open the app -> Enable keyboard -> Select keyboard.
